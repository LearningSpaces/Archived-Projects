<h1><a href="../">KIOSK</a> > printer</h1>
<p>
Statistics about the printer.
</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
		<tr><td>pageCountBW</td>		<td>Integer</td>	<td>The number of BW pages printed</td></tr>
		<tr><td>pageCountColor</td>		<td>Integer</td>	<td>The number of Color pages printed</td></tr>
		<tr><td>totalPageCount</td>		<td>Integer</td>	<td>The total number of pages printed</td></tr>
		<tr><td>allowedPageSize</td>	<td>String</td>		<td>The page size allowed</td></tr>
	</tbody>
</table>