<h1><a href="../">KIOSK</a> > status</h1>
<p>

</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
	<tr><td>kioskStatus</td>		<td>String</td>		<td>Error status</td></tr>
	<tr><td>printerStatus</td>		<td>Color</td>		<td>Color code for kiosk status</td></tr>
	<tr><td>printerAvaiable</td>	<td>Boolean</td>	<td>Is the printer available? 1 for yes, null for no</td></tr>
	<tr><td>printerLCDText</td>		<td>String</td>		<td>Text displaying on the printer LCD</td></tr>
	<tr><td>snmpAlertsText</td>		<td>String</td>		<td>Error alerts in a more readable form</td></tr>
	<tr><td>lastUpdate</td>			<td>Date</td>		<td>The date and time of the last update</td></tr>
	<tr><td>detail</td>				<td>String</td>		<td>Unknown</td></tr>
	</tbody>
</table>