<h1><a href="../">KIOSK</a> > studentCardSettings</h1>
<p>

</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
		<tr><td></td>	<td></td>	<td></td></tr>
	</tbody>
</table>