<h1><a href="../">KIOSK</a> > quickRelease</h1>
<p>
ASSUMED USAGE: Not useful to Learning Spaces. Used by WEPA for remote access and management.
</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
	<tr><td>enabled</td>		<td>Boolean</td>	<td>Is Quick Release enabled?</td></tr>
	<tr><td>serviceURL</td>		<td>URL</td>		<td>URL used for servicing the WEPA</td></tr>
	<tr><td>printInterval</td>	<td>Integer</td>	<td>Unknown</td></tr>
	</tbody>
</table>