<h1><a href="../">KIOSK</a> > location</h1>
<p>
Information regarding the location of the WEPA.
</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
	<tr><td>id</td>						<td>Integer</td>	<td>unique id of the KIOSK location</td></tr>
	<tr><td>locationDecription</td>		<td>String</td>		<td>Description of the location. Usually 'University of Oklahoma'
</td></tr>
	<tr><td>buildingDescription</td>	<td>String</td>		<td>Description of the building. Usually 'University of Oklahoma'
</td></tr>
	<tr><td>campusName</td>				<td>String</td>		<td>Name of the campus. Usually 'University of Oklahoma'
</td></tr>
	<tr><td>streetAddress</td>			<td>String</td>		<td>The street address of the building</td></tr>
	<tr><td>city</td>					<td>Array</td>		<td>The city the WEPA is located in</td></tr>
	<tr><td>state</td>					<td>Array</td>		<td>The state the WEPA is located in</td></tr>
	<tr><td>zipCode</td>				<td>Integer</td>	<td>The zip code the WEPA is located in</td></tr>
	<tr><td>latitude</td>				<td>Double</td>		<td>The latitude coordinate of the WEPA</td></tr>
	<tr><td>longitude</td>				<td>Double</td>		<td>The longitude coordinate of the WEPA</td></tr>
	<tr><td>notes</td>					<td>String</td>		<td>Notes regarding the location</td></tr>
	<tr><td><a href="./supplyBin">supplyBin</a></td>				<td>Array</td>		<td>Unknown</td></tr>
	</tbody>
</table>