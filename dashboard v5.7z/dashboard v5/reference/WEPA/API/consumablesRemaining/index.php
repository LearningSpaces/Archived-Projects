<h1><a href="../">KIOSK</a> > consumablesRemaining</h1>
<p>
Information about the current state of the consumables in the printer.
</p>
<table>
	<thead>
		<td><h3>Variable</h3></td>
		<td><h3>Return Type</h3></td>
		<td><h3>Description</h3></td>
	</thead>
	<tbody>
	<tr><td>belt</td>	<td>Double</td>	<td>Percentage of the belt remaining</td></tr>
	<tr><td>fuser</td>	<td>Double</td>	<td>Percentage of the fuser remaining</td></tr>
	<tr><td><a href="./toner/">toner</a></td>	<td>Array</td>	<td>Array containing the percentage of toner remaining</td></tr>
	<tr><td><a href="./drum/">drum</a></td>	<td>Array</td>	<td>Array containing the percentage of drum remaining</td></tr>
	</tbody>
</table>