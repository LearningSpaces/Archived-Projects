// JavaScript Document

//Used for pulling JSON data from a generic url
//This may be used as a call from each individual data fetching function
//NOTE: The methods performed in this function are very similar to the ones in the other functions
//    so the others are not commented thoroughly
function getAsyncJSON(url,callback){
	//Prints information denoting the pull request start
	console.log("Pulling JSON: "+url);
	//Make a new object for performing an HTTP request
	var xmlHttp = new XMLHttpRequest();
	//Put the function input arguments into a proper array object
	var args = Array.prototype.slice.call(arguments);
	
	//Callback for when the request response is recieved
    xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4){
			console.log("JSON request: status code - "+xmlHttp.status);
			if (xmlHttp.status == 200){
				try{
					args.splice(0,2,JSON.parse(xmlHttp.responseText));
				}
				catch(err){
					console.error("JSON parse error: "+err);
					args.splice(0,2,xmlHttp.responseText);
				}
				console.log(args);
				callback.apply(null,args);
			} else if (xmlHttp.status == 408){
				console.log("JSON request: Timeout. Trying Again.");
				getAsyncJSON.apply(null,args);
			}
		}
    };
	//Log the query
	//NOTE: In most browsers, this will create a clickable link to bring up the request in a new tab
	console.log(url);
	//Open the request
    xmlHttp.open("GET", url, true); // true for asynchronous 
	//Send the request
    xmlHttp.send(null);
}

//Given a query, boolean for display values, and a callback function pulls ServiceNow incidents
function getAsyncCases(query, bDV, callback) {
	var url = './utils/fetchers/ServiceNow.php?query=';
	var xmlHttp = new XMLHttpRequest();
	var args = Array.prototype.slice.call(arguments);
	
	
    xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4){
			if (xmlHttp.status == 200){
				args.splice(0,3,JSON.parse(xmlHttp.responseText));
				callback.apply(null,args);
			} else if (xmlHttp.status == 408){
				getAsyncCases.apply(null,args);
			}
		}
    };
    xmlHttp.open("GET", url+encodeURIComponent(query)+"&dv="+bDV, true); // true for asynchronous 
    xmlHttp.send(null);
};

//Given a query and a callback function pulls WhenIWork shift data
function getAsyncShifts(query,callback) {
	var url = './utils/fetchers/WhenIWork.php?query=';
	var xmlHttp = new XMLHttpRequest();
	var args = Array.prototype.slice.call(arguments);
	
    xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4){
			if (xmlHttp.status == 200){
				try{
					args.splice(0,2,JSON.parse(xmlHttp.responseText));
				}
				catch(err){
					console.error(err);
					args.splice(0,2,xmlHttp.responseText);
				}
				callback.apply(null,args);
			} else if (xmlHttp.status == 408){
				getAsyncShifts.apply(null,args);
			}
		}
    };
    xmlHttp.open("GET", url+encodeURIComponent(query), true); // true for asynchronous 
    xmlHttp.send(null);
};

//Given a callback function pulls TechCheck status data
function getAsyncTechChecks(callback) {
	var url = './utils/fetchers/TechChecks.php';
	var xmlHttp = new XMLHttpRequest();
	
	var args = Array.prototype.slice.call(arguments);
	
    xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4){
			console.log("Tech Check request: status code - "+xmlHttp.status);
			if (xmlHttp.status == 200){
				
				args.splice(0,2,JSON.parse(xmlHttp.responseText)); //Fix  this line
				
				callback.apply(null,args);
			} else if (xmlHttp.status == 408){
				console.log("Case request: Tmeout/No Internet. Trying Again.");
				getAsyncTechChecks.apply(null,args);
			}
		}
    };
    xmlHttp.open("GET", url, true); // true for asynchronous 
    xmlHttp.send(null);
};

//Given a callback function pulls cart status data
function getAsyncCartsStatus(callback) {
	var url = './utils/fetchers/CartStatus.php';
	var xmlHttp = new XMLHttpRequest();
	var args = Array.prototype.slice.call(arguments);
	
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200){
			args.splice(0,1,JSON.parse(xmlHttp.responseText));
            callback.apply(null,args);
		}
    };
    xmlHttp.open("GET", url, true); // true for asynchronous 
    xmlHttp.send(null);
};

//Given a callback function pulls employee stats data
function getAsyncEmployeeStats(callback){
	var url = './utils/fetchers/EmployeeStats.php';
	var xmlHttp = new XMLHttpRequest();
	var args = Array.prototype.slice.call(arguments);
	
    xmlHttp.onreadystatechange = function() { 
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200){
			args.splice(0,1,JSON.parse(xmlHttp.responseText));
            callback.apply(null,args);
		}
    };
    xmlHttp.open("GET", url, true); // true for asynchronous 
    xmlHttp.send(null);
};

//Given a query and a callback function pulls WhenIWork shift data
function getAsyncWEPAStatus(callback) {
	var url = './utils/fetchers/wepa.php';
	var xmlHttp = new XMLHttpRequest();
	var args = Array.prototype.slice.call(arguments);
	
    xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4){
			if (xmlHttp.status == 200){
				try{
					args.splice(0,2,JSON.parse(xmlHttp.responseText));
				}
				catch(err){
					console.error(err);
					args.splice(0,2,xmlHttp.responseText);
				}
				callback.apply(null,args);
			} else if (xmlHttp.status == 408){
				getAsyncShifts.apply(null,args);
			}
		}
    };
    xmlHttp.open("GET", url, true); // true for asynchronous 
    xmlHttp.send(null);
};
