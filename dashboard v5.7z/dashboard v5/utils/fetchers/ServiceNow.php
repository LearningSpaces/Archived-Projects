<?php
	//Base of SN Classroom Query URL
	$classURL = "";
	//Base of SN Building Query URL
	$buildingURL = "";
	//Reference # for LS Classrooms Assignment Group
	$classroomsRef = "";
	//Reference # for LS Labs Assignment Group
	$labsRef = "";
	//Base of SN  Incidents Query URL
	//Has the LS Classrooms & Labs requirement built in
	$incidentURL = "";
	//Base of SN User Query URL
	$userURL = "";
	//Dashboard SN login credentials
	$userPwd = "";
	//ServiceNow CookieJar File
	$cookieJarFolder = "../../tmp/cookies";
	$cookieJar = $cookieJarFolder."/ServiceNow";
	if(!is_dir($cookieJarFolder)){
		mkdir($cookieJarFolder, 0777, true);
	}
	if(!file_exists($cookieJar)){
		$h = fopen($cookieJar,"w");
		fclose($h);
	}
	$cURL_options = array(CURLOPT_HEADER => false,
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
		CURLOPT_USERPWD => $userPwd,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_0,
		CURLOPT_COOKIEJAR => realpath($cookieJar),
		CURLOPT_COOKIEFILE => realpath($cookieJar));
	
	// Reference Numbers for Labs in the Engineering Sector
	$engSectorLabs = array(
		'29ef44d34a36232600877d307cca74f7',
		'8b02cecfc96ad0448731a3a6d0b458cd',
		'29f077a34a362326003f323da4b5940f',
		'29f0c1314a36232601d45a035ca838b0',
		'6f020203c9aad0448731a3a6d0b4584b',
		'8702cecfc96ad0448731a3a6d0b458dc',
		'cf02cecfc96ad0448731a3a6d0b458df',
		'29f255744a3623260129e450a996e841',
		'1f020203c9aad0448731a3a6d0b45805',
		'29f1c65a4a3623260148df7bf58c80ab',
		'4302cecfc96ad0448731a3a6d0b458e3',
		'13020203c9aad0448731a3a6d0b4580a',
		'c302cecfc96ad0448731a3a6d0b458ef',
		'0702cecfc96ad0448731a3a6d0b458f0',
		'29f3385d4a362326010ada054c1a346b',
		'0302cecfc96ad0448731a3a6d0b458f4',
		'ab020203c9aad0448731a3a6d0b45860',
		'9302cecfc96ad0448731a3a6d0b458fa',
		'29fa20bf4a362326014437947df22fd7',
		'90beaac1c9f454808731a3a6d0b45864'
	);
	
	// Reference Numbers for Labs in the Arts & Sciences Sector
	$asSectorLabs = array(
		'1b020203c9aad0448731a3a6d0b45818',
		'29efc6dd4a362326004beedbc8328488',
		'29f007cf4a36232600944541caa810b7',
		'0302cecfc96ad0448731a3a6d0b458c2',
		'8f02cecfc96ad0448731a3a6d0b458c4',
		'0f02cecfc96ad0448731a3a6d0b458ca',
		'4f02cecfc96ad0448731a3a6d0b458c3',
		'edd9653061cbb9000367e57d32fdecdf',
		'29f112574a362326001ea149d78e3571',
		'8f02cecfc96ad0448731a3a6d0b458de',
		'd3020203c9aad0448731a3a6d0b45803',
		'8b02cecfc96ad0448731a3a6d0b458e1',
		'8302cecfc96ad0448731a3a6d0b458e4',
		'29f241744a36232600f767ee82ffdd76',
		'29f7bc344a3623260134d7d7e3b5c0f5',
		'9f020203c9aad0448731a3a6d0b4582d',
		'29f82db74a36232600cfeb19c629a62c',
		'29f8a3b14a3623260055d31cd13126fa',
		'29f8f3944a3623260145ed4cb5178928',
		'5b02cecfc96ad0448731a3a6d0b458ff',
		'29f97de54a3623260151f19c22b99643',
		'5302cecfc96ad0448731a3a6d0b458f5',
		'1302cecfc96ad0448731a3a6d0b458f8',
		'93020203c9aad0448731a3a6d0b45812',
		'd3020203c9aad0448731a3a6d0b45813'
	);
	
	// Reference Numbers for Labs in the Residential Sector
	$resSectorLabs = array(
		'cf02cecfc96ad0448731a3a6d0b458d2',
		'c302cecfc96ad0448731a3a6d0b458be',
		'4702cecfc96ad0448731a3a6d0b458c6',
		'9ecf0a7d2047d100fc00e8f653e01581',
		'56cf0a7d2047d100fc00e8f653e01583',
		'5b020203c9aad0448731a3a6d0b4583e',
		'4f02cecfc96ad0448731a3a6d0b458ec',
		'b5a7e89cb5c4f9005c70d936c5e6b4c2',
		'4702cecfc96ad0448731a3a6d0b458d8',
		'5ecf0a7d2047d100fc00e8f653e01588',
		'8302cecfc96ad0448731a3a6d0b458c9',
		'6b020203c9aad0448731a3a6d0b4584a',
		'29f14eba4a36232601c0e97e4fe469d3',
		'29f1917c4a36232600ad2f9bcec62021',
		'4702cecfc96ad0448731a3a6d0b458d0',
		'dae0daf54a362326013e35881e44688e',
		'4b02cecfc96ad0448731a3a6d0b458e6',
		'0702cecfc96ad0448731a3a6d0b458e9',
		'29f7ef814a362326016f1e99f3328192',
		'52cf0a7d2047d100fc00e8f653e01591',
		'0b02cecfc96ad0448731a3a6d0b458ea',
		'5ecf0a7d2047d100fc00e8f653e01593',
		'6f020203c9aad0448731a3a6d0b4586a',
		'29f8dea04a362326007a26eb126ddddf',
		'2375af98e8a661405c70b5f77e02f266',
		'6d590b34e8126d005c70b5f77e02f2c2',
		'8299c734e8126d005c70b5f77e02f27f',
		'1f020203c9aad0448731a3a6d0b45827'
	);
	
	//Given a reference number, returns the associated classroom object
	function getClassroomByName($u_room){
		//Access the classroom query url and user credentials locally
		global $classURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($classURL."sysparm_query=u_room=".urlencode($u_room));
		curl_setopt_array($ch, $cURL_options);
		
		//get query JSON results
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);
		//return the first (and only) classroom object
		return $data->records[0];
	}
	
	//Given a building full name, returns the associated building object
	//Useful since the display values for buildings are full names
	function getBuildingByFullName($full_name){
		//Access the building query url and user credentials locally
		global $buildingURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($buildingURL."sysparm_query=full_name=".urlencode($full_name));
		curl_setopt_array($ch, $cURL_options);
		
		//get query JSON results
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);;
		//return the first (and only) building object
		return $data->records[0];
	}
	
	//Given a user 4x4, returns the associated user object
	//Useful since the display values for users are the 4x4s
	function getUserFrom4x4($fourByfour){
		//Access the user query url and user credentials locally
		global $userURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($userURL."sysparm_query=user_name=".$fourByfour);
		curl_setopt_array($ch, $cURL_options);
		
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);
		//return the first (and only) user object
		return $data->records[0];
	}
	
	//Given a query, returns an array of user objects
	function getUsers($params = "department=acaa289649b8150422f221058fac5a28"){
		//Access the user query url and user credentials locally
		global $userURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($userURL."sysparm_query=".urlencode($params));
		curl_setopt_array($ch, $cURL_options);
		
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);
		//return the array of userobjects
		return $data->records;
	}
	
	//Given a query, returns an array of building objects
	function getBuildings($params = ""){
		//Access the building query url and user credentials locally
		global $buildingURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($buildingURL."sysparm_query=".urlencode($full_name));
		curl_setopt_array($ch, $cURL_options);
		
		//get query JSON results
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);;
		//return the array of building objects
		return $data->records;
	}
	
	function getClassrooms($params = ""){
		//Access the classroom query url and user credentials locally
		global $classURL, $cURL_options;
		//make a curl request object and set parameters
		$ch = curl_init($classURL."sysparm_query=".urlencode($params));
		curl_setopt_array($ch, $cURL_options);
		
		//get query JSON results
		$json = curl_exec($ch);
		//check for http errors
		if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		//release curl object
		curl_close($ch);
		//decode JSON text into JSON objects
		$data = json_decode($json);
		//return the first (and only) classroom object
		return $data->records;
	}
	
	//Given a query and boolean for whether to show display values, returns an
	//array of the raw incident information from ServiceNow
	function getIncidents($params = "active=true", $bDV = true){
		global $incidentURL, $cURL_options;
		$ch = curl_init($incidentURL."^".urlencode($params).($bDV?"&displayvalue=all":""));
		curl_setopt_array($ch, $cURL_options);
 
        $json = curl_exec($ch);
        if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
        curl_close($ch);
		$data = json_decode($json);
		//return all of the aquired incident objects
		return $data->records;
	}
	
	//Given a query and boolean for whether to show display values, returns an
	//    array of the incident information from ServiceNow
	//Includes the raw ServiceNow information and the additional fields of:
	//    Sector
	//    Time Available
	//    Combined Location (e.g. SEC 1034)
	function getIncResults($query = "active=true", $bDV = true){
		global $engSectorLabs, $asSectorLabs, $resSectorLabs;
		$results = getIncidents($query, $bDV);
		if($bDV){
			foreach($results as $result){
				preg_match("#(\{)[ -z]+(?=\})#", $result->dv_short_description, $time);
				if(count($time) > 0){
					$result->time_available = substr($time[0], 1);
				} else {
					$result->time_available = "";
				}
				
				if (in_array($result->u_building, $engSectorLabs)){
					$result->sector = 0;
				} else if(in_array($result->u_building, $asSectorLabs)){
					$result->sector = 1;
				} else if(in_array($result->u_building, $resSectorLabs)){
					$result->sector = 2;
				} else {
					$result->sector = 3;
				}
				
				if($result->dv_u_building != ""){
					$result->combined_location = getBuildingByFullName($result->dv_u_building)->u_regents_code;
				}
				$result->combined_location .= " ".$result->dv_u_classroom;
				
			}
		}
		
		return $results;
	}
	
	//Used for consistency with the other PHP data fetchers
	//Collects the data and encodes it to serialized JSON text before returning it
	function getJSONResults($params, $dv = true){
		//Gets the incident object array for the query params specified
		$results = getIncResults($params, $dv);
		
		//Encodes the array and returns it
		return json_encode($results);
	}
	
	if(isset($_GET["new_session"])){
		$h = fopen($cookieJar,"w");
		fclose($h);
	}
	//Checks for the test key which dumps the input GET data
	if(isset($_GET["test_cookies"])){
		$ch = curl_init($incidentURL."^active=true");
		curl_setopt_array($ch, $cURL_options);
		curl_setopt($ch, CURLOPT_HEADER, true);
        $result = curl_exec($ch);
        if(curl_errno($ch)){
			print_r('Curl error: '.curl_error($ch)."<br/>");
		}
		echo $result . "<br/>";
        curl_close($ch);
		$h = fopen($cookieJar,"r");
		$cookies = fread($h, filesize($cookieJar));
		print_r($cookies);
		fclose($h);
		exit();
	}
	if(isset($_GET["test_get"])){
		var_dump($_GET);
	}
	
	//Checks to see if a query was provided
	//If no query is provided, returns an empty array
	if(isset($_GET["query"])){
		//query is set
		if(isset($_GET["dv"])){
			//dv is set and checks to see if dv is explicitly set to false
			echo getJSONResults($_GET["query"],$_GET["dv"]!="false");
		} else {
			//dv not set so it defaults dv to true
			echo getJSONResults($_GET["query"], true);
		}
	} else {
		//query is not set
		echo json_encode(array());
	}
?>