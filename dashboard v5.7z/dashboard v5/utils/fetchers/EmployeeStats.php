<?php
	$ListFile = '';
	$HistoryFile = '';
	
	function getRawArrays($File){
		
		$arrResult  = array();
		$handle     = fopen($File, "r");
		if(empty($handle) === false) {
			while(($data = fgetcsv($handle, 1000, ",")) !== FALSE){
				$arrResult[] = $data;
			}
    		fclose($handle);
		}
		return array_delete(0,$arrResult);
	}
	
	function array_delete($idx,$array) {  
    	unset($array[$idx]);  
    	return (is_array($array)) ? array_values($array) : null;  
	}
	
	function getJSONResults(){
		global $ListFile, $HistoryFile;
		$raw = getRawArrays($ListFile);
		$listResults = array();
		for($i = 0; $i < count($raw); $i++){
			if(count($raw[$i] > 0)){
				if(count($raw[$i]) > 1){
					if(count($raw[$i]) > 2){
						$listResults[] = array('user' => $raw[$i][0], '4x4'=> $raw[$i][1], 'sys_id'=> $raw[$i][2]);
					} else {
						$listResults[] = array('user' => $raw[$i][0], '4x4'=> $raw[$i][1], 'sys_id'=> "");
					}
				} else {
					$listResults[] = array('user' => $raw[$i][0], '4x4'=> "", 'sys_id'=> "");
				}
			}
		}
		$raw = getRawArrays($HistoryFile);
		$historyResults = array();
		for($i=0; $i < count($raw); $i++){
			$historyResults[] = array('timestamp'=>$raw[$i][0],'names'=>$raw[$i][1],'engChecks'=>$raw[$i][2],'resChecks'=>$raw[$i][3],'asChecks'=>$raw[$i][4],'comments'=>$raw[$i][5]);
		}
		return json_encode(array('list'=>$listResults,'submissions'=>$historyResults));
	}
	
	if(isset($_GET["test"])){
		$myarray = json_decode(getJSONResults());
		$out  = "";
		$out .= "<table>";
		foreach($myarray as $key => $element){
			$out .= "<tr>";
			foreach($element as $subkey => $subelement){
				$out .= "<td>$subelement</td>";
			}
			$out .= "</tr>";
		}
		$out .= "</table>";
		
		echo $out;
	} else {
		echo getJSONResults();
	}
?>