<?php
	//WhenIWork provided files
	require("../../vendor/autoload.php");
	
	//Make sure timezone is set correctly.
	//Timezone is a required setting in PHP.ini for PHP 5.6 so the timezone is set on the LS Server
	date_default_timezone_set("America/Chicago");
	
	// Pull the json config file and assign the values to variables
	//Gets password and username for WIW and the API key fro communication
	$config = json_decode(file_get_contents("../../config.json"));
	$username = $config->UserName;
	$password = $config->Password;
	$apiKey = $config->APIKey;
	
	// API info and token generation
	$response = Wheniwork::login($apiKey, $username, $password);
	$wiw = new Wheniwork($response->login->token);
	
	//Gets the users for a particular shift (1-7) and specific location id
	function getShiftUsers($shiftNum, $location){
		
		//makes the WIW object visible in the local scope
		global $wiw;
		//Define the time bounds for the WiW request
		$startTime = date("Y-m-d H:i:s",strtotime(getStartTime($shiftNum))+30*60);
		$endTime = date("Y-m-d H:i:s",strtotime(getEndTime($shiftNum))-30*60);

		//Request the Shifts from WhenIWork using:
		//    location_id: EL
		//    position_id: Technicians
		//    start:       Start Time
		//    end:         End Time
		$current = $wiw->get('shifts', array(
			"location_id" => $location,
			//"position_id" => 315394,
			"start" => $startTime,
			"end"   => $endTime
			)
		);
		//Only pull the shifts from the results
		$current = $current->shifts;
		
		//Arrays used to store the names and associated phone numbers from when i work
		//currentIndex used as index when assigning values to arrays
		$currentIndex = 0;
		$names = array();
		$phoneNumbers = array();
		
		if($shiftNum <=6){
			//Iterate through the returned shifts
			foreach($current as $shift){
				//Get the user for this shift
				$user = getUser($shift->user_id);
				//Check if the user is a Technician and their shift starts before the next shift
				//if(in_array(315394,$user->positions) &&
				if ((strtotime($shift->start_time) < strtotime(getStartTime($shiftNum+1)) || $shiftNum >= 5)){
					//Add the users name and associated phone number to the names and phoneNumbers arrays
					$names[$currentIndex] = $user->first_name . " " . $user->last_name;
					$phoneNumber = $user->phone_number;
					if (strlen($phoneNumber) == 12) { 
						$phoneNumbers[$user->first_name . " " . $user->last_name] = "(" . substr($phoneNumber, 2, 3) . ") " . substr($phoneNumber, 5, 3) . "-" . substr($phoneNumber, 8, 4);
					} else {
						$phoneNumbers[$user->first_name . " " . $user->last_name] = $phoneNumber;
					}
					$currentIndex++;
				}
			}
		}
		
		//Sort the names into alphabetical order
		sort($names);

		return array('names' => $names, 'phoneNumbers' => $phoneNumbers);
	}
	
	//
	function getUser($user_id){
		//Make the WIW object visible in the local scope
		global $wiw;
		//Get the user object based on an id
		$user = $wiw->get("users/".$user_id)->user;
		return $user;
	}
	
	//Gets the shift based on an input time
	//Shifts are the following ranges:
	//    07:30am-10:30am
	//    10:00am-12:30pm
	//    12:00pm-02:30pm
	//    02:00pm-04:30pm
	//    04:00pm-06:30pm
	//    06:00pm-08:30pm
	//    08:00pm-10:30pm
	//During the half hour transitions, it uses the previous shifts times
	function getShift($time){
		$minutes = floor(($time - strtotime("00:00"))/60);
		//7:30-10:30
		if($minutes >= 7.5*60 && $minutes < 10.5*60-1){
			return 0;
		}
		//10:30-12:30
		else if($minutes >= 10.5*60 && $minutes < 12.5*60-1){
			return 1;
		}
		//12:30-2:30
		else if($minutes >= 12.5*60 && $minutes < 14.5*60-1){
			return 2;
		}
		//2:30-4:30
		else if($minutes >= 14.5*60 && $minutes < 16.5*60-1){
			return 3;
		}
		//4:30-6:30
		else if($minutes >= 16.5*60 && $minutes < 18.5*60-1){
			return 4;
		}
		//6:30-8:30
		else if($minutes >= 18.5*60 && $minutes < 20.5*60-1){
			return 5;
		}
		//8:30-10:30
		else if($minutes >= 20.5*60 && $minutes < 22.5*60-1){
			return 6;
		}
		//None of the above
		else {
			return -1;
		}
	}
	
	//Returns the start times for each shift
	function getStartTime($shift = 0){
		switch ($shift){
			case 0:
				return date("Y-m-d H:i:s",strtotime("07:30"));
			case 1:
				return date("Y-m-d H:i:s",strtotime("10:00"));
			case 2:
				return date("Y-m-d H:i:s",strtotime("12:00"));
			case 3:
				return date("Y-m-d H:i:s",strtotime("14:00"));
			case 4:
				return date("Y-m-d H:i:s",strtotime("16:00"));
			case 5:
				return date("Y-m-d H:i:s",strtotime("18:00"));
			case 6:
				return date("Y-m-d H:i:s",strtotime("20:00"))
			default:
				return null;
		}
	}
	
	//Gets the end times for each shift
	function getEndTime($shift = 0){
		switch ($shift){
			case 0:
				return date("Y-m-d H:i:s",strtotime("10:30"));
				break;
			case 1:
				return date("Y-m-d H:i:s",strtotime("12:30"));
				break;
			case 2:
				return date("Y-m-d H:i:s",strtotime("14:30"));
				break;
			case 3:
				return date("Y-m-d H:i:s",strtotime("16:30"));
				break;
			case 4:
				return date("Y-m-d H:i:s",strtotime("18:30"));
				break;
			case 5:
				return date("Y-m-d H:i:s",strtotime("20:30"));
				break;
			case 6:
				return date("Y-m-d H:i:s",strtotime("22:30"));
				break;
			default:
				return null;
				break;
		}
	}
	
	//Check if a query was entered
	if(isset($_GET['query'])){
		//check if the shift is specified
		if(strpos($_GET['query'], 'current_shift=')){
			$shift = '';
			//get matching string from query
			preg_match("#current_shift=\d#", htmlspecialchars($_GET['query']), $shift);
			//remove "current_shift=" from string
			$shift = substr($shift, 15);
			//convert the string to an integer
			$shift = intval($shift);
			//echo the JSON encoded results
			echo getJSONResults($shift);
		//Check if the query was specified for now
		} elseif($_GET['query'] == 'now') {
			//get the shift for the current time and' echo the JSON encoded results
			echo getJSONResults(getShift(time()));
		}
	//No query was entered
	} else {
		//return an empty array
		echo json_encode(array());
	}
	
	//Used to get the results in correctly formatted JSON text
	function getJSONResults($shiftNum){
		
		//Get the users for the current shift
		$current = getShiftUsers($shiftNum, 131565);
		$currentCOA = getShiftUsers($shiftNum, 131576);
		$currentSarkeys = getShiftUsers($shiftNum, 131584);
		$currentHemlerich = getShiftUsers($shiftNum, 243480);
		$currentCouch = getShiftUsers($shiftNum, 703771);
		
		//Get the users for the next shift
		$next = getShiftUsers($shiftNum+1, 131565);
		
		
		//Put the resutls into an associative array
		$results = array('current' => $current, 'next' => $next, 'currentCOA' => $currentCOA, 'currentSarkeys' => $currentSarkeys, 'currentHemlerich' => $currentHemlerich, 'currentCouch' => $currentCouch);
		
		
		//Return the results encoded in a serializable JSON format
		return json_encode($results);
	}
?>