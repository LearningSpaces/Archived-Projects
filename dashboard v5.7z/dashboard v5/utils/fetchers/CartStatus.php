<?php
	//URL for the Google Spreadsheet sheet CSV file that contains the the Cart status information
	$File = '';
	
	//Pulls the raw 2D array data from the CSV file
	function getCartsArrays(){
		//Allow access to the global variable $File which contains the CSV file URL
		global $File;
		
		//Initialize an empty results array
		$arrResult  = array();
		//Open the CSV file for reading
		$handle     = fopen($File, "r");
		//Make sure something was opened
		if(empty($handle) === false) {
			while(($data = fgetcsv($handle, 1000, ",")) !== FALSE){
				$arrResult[] = $data;
			}
    		fclose($handle);
		}
		return array_delete(0,$arrResult);
	}
	
	function array_delete($idx,$array) {  
    	unset($array[$idx]);  
    	return (is_array($array)) ? array_values($array) : null;  
	}
	
	function getJSONResults(){
		$carts = array();
		$raw = getCartsArrays();
		foreach($raw as $row){
			$carts[] = array(
				'cart' => $row[0],
				'person' => $row[1],
				'number' => $row[2],
				'location' => $row[3],
				'status' => $row[4],
				'status_code' => $row[9]
			);
		}
		$n_in = 0;
		$n_out = 0;
		$n_docked = 0;
		foreach($carts as $cart){
			switch($cart["status_code"]){
				case (0):
					$n_docked++;
					break;
				case (1):
					$n_in++;
					break;
				case(2):
					$n_out++;
					break;
			}
		}
		$results = array(
			'carts' => $carts,
			'in' => $n_in,
			'out' => $n_out,
			'docked' => $n_docked
		);
		
		return json_encode($results);
	}
	
	echo getJSONResults();
?>