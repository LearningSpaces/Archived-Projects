// JavaScript Document
function Queue(anims){
	
	_framerate = 30;
	_timeoutId = -1;
	_queue = anims;
	
	this.clear = function(){
		_queue = [];
	}
	
	this.add = function(anim){
		_queue.push(anim);
	}
	
	this.remove = function(index){
		_queue.splice(index,0);
	}
	
	this.draw = function(){
		if(!_queue[0].draw()){
			_queue.splice(0,1);
		}
	}
	
	this.stop = function(){
		clearTimeout(_timeoutId);
	}
	
	this.play = function(){
		_timeoutId = setTimeout(this.draw, 1/_framerate);
	}
}

function AnimPath(cvs, p1, p2, frames) {
	
	var _cvs = cvs;
	var _ctx = _cvs.getContext("2d");
	var _p1 = p1;
	var _p2 = p2;
	var _frames = frames;
	var _legs = [];
	var _curFrame = 0;
	_ctx.beginPath();
	
	this.draw = function(){
		var nextPoint = Point2D.lerp(_p1, _p2, _curFrame/_frames);
		_ctx.lineTo(nextPoint.x, nextPoint.y);
		_ctx.stroke();
		_curFrame++;
		
		if(_curFrame > _frames){
			_curFrame = _frames;
			return false;
		} else {
			return true;
		}
	}
	
	this.reset = function(){
		_curFrame = 0;
		_ctx.clearRect(0, 0, cvs.width, cvs.height);
		_ctx.beginPath();
	}
	
	this.revPlay = function(){
		var nextPoint = Point2D.lerp(_p1, _p2, _curFrame/_frames);
		_ctx.lineTo(nextPoint.x, nextPoint.y);
		_ctx.stroke();
		_curFrame--;
		
		if(_curFrame < 0){
			_curFrames = 0;
			return false;
		} else {
			return true;
		}
	}
	
	this.getPoints = function(){
		return this.points;
	}
	
	this.setPoints = function(p1,p2){
		_p1 = p1;
		_p2 = p2;
	}
}

function Point2D(x,y){

	this.y = y;
	this.x = x;
	
	Point2D.lerp = function(p1,p2,percent){
		return new Point2D(p1.x+(p2.x-p1.x)*percent, p1.y+(p2.y-p1.y)*percent);
	}
	
	Point2D.dist = function(p1,p2){
		return Math.sqrt(Point2D.distSquared(p1,p2));
	}
	
	Point2D.distSquared = function(p1,p2){
		dx = p2.x-p1.x;
		dy = p2.y-p1.y;
		return dx*dx+dy*dy;
	}
}