<!DOCTYPE html>

<html>
    <head>
        <title>WhenIWork Stuff</title>
        <style>
            .wheniwork_user_box {
                background-color: #841617;
                text-align: center;
                border-radius: 10px;
				width: 100px;
				height: 100px;
				box-shadow: 5px 5px 3px  #666666;
				
                color: #FDF9D8;
                font-family: "Garamond","Calibri",Times,serif;
                font-size: 20px;
            }
			
			.wheniwork_user_box span {
				
			}
            
            body, html {
                background-color: #FFAAA;
                width: 100%;
                height: 100%;
            }
			
			table {
				width: 50%;
				height: 100%;
				padding: 10px;
				border-spacing: 10px;
				background-color: #FDF9D8;
				
				border: 1px solid black;
				border-radius: 10px;
			}
			
			table th {
				font-family: "Calibri",Times,serif;
				font-size:50px;
				color: #841617;
			}
        </style>
    </head>
    <body>
    <?php
        require("vendor/autoload.php");
        
        date_default_timezone_set("America/Chicago");
        
        // Pull the json config file and assign the values to variables
        $config = json_decode(file_get_contents("./config.json"));
        $username = $config->UserName;
        $password = $config->Password;
        $apiKey = $config->APIKey;
        
        // API info and token generation
        $response = Wheniwork::login($apiKey, $username, $password);
        $wiw = new Wheniwork($response->login->token);
        
        function getShiftDivs($shiftNum){
            $str = "";
            if (1 /*gettype($response->code) !== "integer"*/ ) {
                global $response, $wiw;
				$startTime = date("Y-m-d H:i:s",strtotime(getStartTime($shiftNum))+30*60);
				$endTime = date("Y-m-d H:i:s",strtotime(getStartTime($shiftNum))+120*60);

                $current = $wiw->get('shifts', array(
                    "location_id" => 131565,
                    "position_id" => 315394,
					"start" => $startTime,
                    "end"   => $endTime
                    )
                );
                $current = $current->shifts;
                
                if($shiftNum <=5){
                    foreach($current as $shift){
                        if(in_array(315394,getUser($shift->user_id)->positions)
                        && (strtotime($shift->start_time) < strtotime(getStartTime($shiftNum+1)) || $shiftNum >= 5)){
                            $str .= makeRow($shift);
                        }
                    }
                } else {
                    $str .= "<tr><td class='wheniwork_user_box'><b>No More Shifts Today</b></td></tr>";            
                }
            }
            return $str;
        }
        
        function getUser($user_id){
            global $wiw;
            $user = $wiw->get("users/{$user_id}")->user;
            return $user;
        }
        
        function makeDiv($shift = null){
            if($shift == null){
                return "";
            }
            $user = getUser($shift->user_id);
            if(in_array(315394,$user->positions)){
                $div = "<div class='wheniwork_user_box'>";
                $div .= "<h1>".$user->first_name." ".$user->last_name."</h1><br/>";
				$div .= "<h2>".date("H:m",strtotime($shift->start_time))."-".date("H:m",strtotime($shift->end_time))."</h2>";
                $div .= "</div><br/>";
                return $div;
            }
            return "";
        }
		
		function makeRow($shift = null){
            if($shift == null){
                return "";
            }
            $user = getUser($shift->user_id);
            if(in_array(315394,$user->positions)){
                $row = "<tr><td class='wheniwork_user_box'>";
                $row .= "<b>".$user->first_name." ".$user->last_name."</b>";
				$row .= "<br/>".date("h:i",strtotime($shift->start_time))."-".date("h:i",strtotime($shift->end_time));
                $row .= "</td></tr>\n";
                return $row;
            }
            return "";
        }
		
		
        function getShift($time){
            $minutes = floor(($time - strtotime("00:00"))/60);
            
            if($minutes >= 7.5*60 && $minutes < 10*60-1){
                return 0;
            }
            else if($minutes >= 10*60 && $minutes < 12*60-1){
                return 1;
            }
            else if($minutes >= 12*60 && $minutes < 14*60-1){
                return 2;
            }
            else if($minutes >= 14*60 && $minutes < 16*60-1){
                return 3;
            }
            else if($minutes >= 16*60 && $minutes < 18*60-1){
                return 4;
            }
            else if($minutes >= 18*60 && $minutes < 20*60-1){
                return 5;
            }
            else {
                return -1;
            }
        }
        
        function getStartTime($shift = 0){
            switch ($shift){
                case 0:
                    return date("Y-m-d H:i:s",strtotime("07:30"));
                    break;
                case 1:
                    return date("Y-m-d H:i:s",strtotime("10:00"));
                    break;
                case 2:
                    return date("Y-m-d H:i:s",strtotime("12:00"));
                    break;
                case 3:
                    return date("Y-m-d H:i:s",strtotime("14:00"));
                    break;
                case 4:
                    return date("Y-m-d H:i:s",strtotime("16:00"));
                    break;
                case 5:
                    return date("Y-m-d H:i:s",strtotime("18:00"));
                    break;
                default:
                    return null;
                    break;
            }
        }
        
        function getEndTime($shift = 0){
            switch ($shift){
                case 0:
                    return date("Y-m-d H:i:s",strtotime("10:30"));
                    break;
                case 1:
                    return date("Y-m-d H:i:s",strtotime("12:30"));
                    break;
                case 2:
                    return date("Y-m-d H:i:s",strtotime("14:30"));
                    break;
                case 3:
                    return date("Y-m-d H:i:s",strtotime("16:30"));
                    break;
                case 4:
                    return date("Y-m-d H:i:s",strtotime("18:30"));
                    break;
                case 5:
                    return date("Y-m-d H:i:s",strtotime("20:30"));
                    break;
                default:
                    return null;
                    break;
            }
        }
    ?>
    <div style="width:500px;">
        <table style="float:left;">
       		<tr><th>Current Shifts</th></tr>
            <?php echo getShiftDivs(getShift(time()));?>
        </table>
        <table style="float:right;">
        	<tr><th>Next Shifts</th></tr>
            <?php echo getShiftDivs(getShift(time())+1);?>
       </table>
    </div>
    </body>
</html>