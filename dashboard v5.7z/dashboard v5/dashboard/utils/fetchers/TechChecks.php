<?php

	//URL for the Google Spreadsheet sheet CSV file that contains the the TechCheck status information
	
	//Official Spreadsheet
	//$File = 'https://docs.google.com/spreadsheets/d/10OMOOV9WRFX-ZmI3W11D3gSm8-Lu4qWH44p8tcS3t9w/export?gid=739518981&format=csv';
	
	//Official Spreadsheet 2
	$File = 'https://docs.google.com/spreadsheets/d/1x7VNl4hcCuSWmRLrn73CfgTmbV6IvpqLlRciqhLbcI0/export?gid=0&format=csv';
	
	
	//Dev Spreadsheet
	//$File = 'https://docs.google.com/spreadsheets/d/1I1wjCYisOrHOIcY-bAGSmq3l6wN8yYwnlWb4oXdt2zw/export?gid=739518981&format=csv';
	//$File = 'https://docs.google.com/spreadsheets/d/1-OixsEm1QtQhI6WcKCCvh7cSZKDP3XmBDhFkUG0DvW4/export?gid=0&format=csv';
	
	//Pulls the raw 2D array data from the CSV file
	function getChecksArrays(){
		//Allow access to the global variable $File which contains the CSV file URL
		global $File;
		
		//Initialize an empty array
		$arrResult  = array();
		//Open the CSV file for reading
		$handle     = fopen($File, "r");
		//Make sure something was opened
		if(empty($handle) === false) {
			//Pull each line until no lines are returned
			while(($data = fgetcsv($handle, 1000, ",")) !== FALSE){
				//Add the cell array for each line as a new array value
				$arrResult[] = $data;
			}
			//Close the opened file
    		fclose($handle);
		}
		
		//Return the results execpt for the header line
		return array_delete(0,$arrResult);
	}
	
	//Get a 2d array consisting of all the sectors and labs
	function getLabs($checks){
		
		$labArrays = array();
		
		for ($columnIndex = 1; $columnIndex < count($checks[0]); $columnIndex = $columnIndex + 2) {
			$results = array();
			$secorName = "";
			$labsCompleted = 0;
			$labsNeedingWork = 0;
			$labsCouldNotGetIn = 0;
			for ($rowIndex = 0; $rowIndex < count($checks); $rowIndex++) {
				if ($rowIndex == 0) {
					$sectorName = $checks[0][$columnIndex];
				}
				else {
					if($checks[$rowIndex][$columnIndex] != "") {
						//$results[$checks[$rowIndex][$columnIndex]] = $checks[$rowIndex][$columnIndex+1];
						$labStatus = 0;
						if (count($checks[$rowIndex]) > $columnIndex + 1) {
							$labStatus = $checks[$rowIndex][$columnIndex+1];
						}
						
						$results[$rowIndex-1][0] = $checks[$rowIndex][$columnIndex];
						$results[$rowIndex-1][1] = $labStatus;
						
						if ($labStatus == 1) {
							$labsCompleted++;
						} elseif ($labStatus == 2) {
							$labsNeedingWork++;
						} elseif ($labStatus == 3) {
							$labsCouldNotGetIn++;
						}
					}
				}
			}
			
			$labArrays[($columnIndex - 1)/2] = array('sectorName' => $sectorName, 'results' => $results, 'total' => count($results), 'couldNotGetIn' => $labsCouldNotGetIn, 
													 'completed' => $labsCompleted, 'workRequired' => $labsNeedingWork, 'remaining' => (count($results)-($labsCompleted + $labsNeedingWork))); //'remaining' => (count($results)-$labsCompleted));
		}
		
		for ($i = 0; $i < count($labArrays); $i++) {
			$returnValue["sector{$i}"] = $labArrays[$i];
		}
		
		return $returnValue;
	}
	
	//Array operator that removes the array value at point $idx
	function array_delete($idx,$array) {  
		//Removes the value at $idx
    	//unset($array[$idx]);
		//Checks if $array is still an array (if the last value was removed)
    	return (is_array($array)) ? array_values($array) : null;  
	}
	
	if(isset($_GET["test"])){
		$myarray = getChecksArrays();
		$out  = "";
		$out .= "<table>";
		foreach($myarray as $key => $element){
			$out .= "<tr>";
			foreach($element as $subkey => $subelement){
				$out .= "<td>$subelement</td>";
			}
			$out .= "</tr>";
		}
		$out .= "</table>";
		
		echo $out;
	} else {
		echo getJSONResults();
	}
	
	/*Get data from the $File spreadsheet, compile the information into a usuable array, and encode the array into a JSON object.
	* @return  JSON encoded array from the getLabs function
	*/
	function getJSONResults(){
		$raw = getChecksArrays();
		
		$results = getLabs($raw);
		
		return json_encode($results);
	}
?>