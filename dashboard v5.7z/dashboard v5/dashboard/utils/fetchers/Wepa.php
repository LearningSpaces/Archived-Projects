<?php
	// Print a Json String. This will either display it on the page or send it to the place that called this script
	echo getJsonResults();
	
	function getJsonResults(){
		$rawData = getData();
		
		$selectedData = parseData($rawData);
		
		return json_encode($selectedData);
	}
	
	function getData(){
		$url = "http://cs.wepanow.com/maps/kiosk-list.php?groupId=148&groupName=OU&subgroupName=false";
		//$url = "http://cs.wepanow.com/maps/kiosk-list.php?groupId=123&groupName=JCJC&subgroupName=false";
		$ch = curl_init();
	
		//Set URL
		curl_setopt($ch, CURLOPT_URL, $url);
		//Set to return a String
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
		$received = curl_exec($ch);
		
		curl_close($ch);
	
		$parsed = substr($received,1,-1);
		
		return json_decode($parsed, TRUE);
	}
	
	function parseData($data){
		$info = array();
		
		for($index = 0; $index < count($data); $index++){
			$name = $data[$index]['name'];
			$description = $data[$index]['description'];
			
			$status = array();
			$status['alerts'] = $data[$index]['status']['kioskStatus'];
			$status['color'] = $data[$index]['status']['printerStatus'];
			$status['available'] = $data[$index]['status']['printerAvailable'];
			$status['printerText'] = $data[$index]['status']['printerLCDText'];
			
			$consumables = $data[$index]['consumablesRemaining'];
			
			$kiosk = array();
			$kiosk['name'] = $name;
			$kiosk['description'] = $description;
			$kiosk['status'] = $status;
			$kiosk['consumables'] = $consumables;
			
			$info[$index] = $kiosk;
		}
		
		return $info;
	}
?>