<?php
	require("../../vendor/autoload.php");
	
	date_default_timezone_set("America/Chicago");
	
	// Pull the json config file and assign the values to variables
	$config = json_decode(file_get_contents("../../config.json"));
	$username = $config->UserName;
	$password = $config->Password;
	$apiKey = $config->APIKey;
	
	// API info and token generation
	$response = Wheniwork::login($apiKey, $username, $password);
	$wiw = new Wheniwork($response->login->token);
	
	function getUsersJSON($userID){
		//Make global variables accessible
		global $wiw;
		
		$user = $wiw->get('times/user/'.$userID);
		
		//return json_encode($user);
		
		$info = array(
			'userID'=>$userID,
			'punchedIn'=>$user->user->punch_state->can_punch_out
		);
		
		return json_encode($info);
	}
	echo getUsersJSON(htmlspecialchars($_GET["query"]));
?>