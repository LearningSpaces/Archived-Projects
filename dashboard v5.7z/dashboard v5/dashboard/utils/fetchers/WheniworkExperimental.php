<?php
	
	//WhenIWork provided files
	require("../../vendor/autoload.php");
	
	//Make sure timezone is set correctly.
	//Timezone is a required setting in PHP.ini for PHP 5.6 so the timezone is set on the LS Server
	date_default_timezone_set("America/Chicago");
	
	// Pull the json config file and assign the values to variables
	//Gets password and username for WIW and the API key fro communication
	$config = json_decode(file_get_contents("../../config.json"));
	$username = $config->UserName;
	$password = $config->Password;
	$apiKey = $config->APIKey;
	
	// API info and token generation
	$response = Wheniwork::login($apiKey, $username, $password);
	$wiw = new Wheniwork($response->login->token);
	
	//echo json_encode($wiw->get('users/'));
	//echo json_encode($wiw->get('times/user/3993233')->user);
	//echo json_encode($wiw->get('times/user/9274421')->user->punch_state->can_punch_out);
	
	//date("Y-m-d H:i:s",strtotime(getStartTime($shiftNum))+30*60);
	
	echo json_encode($wiw->get('schedule/',array(
		'location_id' => 131576,
		'include_open' => false,
		'unpublished' => false,
		'deleted' => false,
		'start' => '2017-01-19 14:00:00', //date("Y-m-d H:i:s",time()),
		'end'   => '2017-01-19 16:30:00'))->shifts); //date("Y-m-d H:i:s",time()+15*60))));
	
	
?>