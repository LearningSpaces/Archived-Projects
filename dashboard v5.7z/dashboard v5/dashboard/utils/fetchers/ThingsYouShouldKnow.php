<?php

	//URL for the Google Spreadsheet sheet CSV file that contains the the TechCheck status information

	//Dev Spreadsheet
	$File = 'https://docs.google.com/spreadsheets/d/1CYq4ZOhwRAmMbpOH2u5HhrMfGJgTglevrK3k-9hDeb0/export?gid=0&format=csv';
	
	//Pulls the raw 2D array data from the CSV file
	function getQuotesOfTheDay(){
		//Allow access to the global variable $File which contains the CSV file URL
		global $File;
		
		//Initialize an empty array
		$arrResult  = array();
		//Open the CSV file for reading
		$handle     = fopen($File, "r");
		//Make sure something was opened
		if(empty($handle) === false) {
			//Pull each line until no lines are returned
			while(($data = fgetcsv($handle, 1000, ",")) !== FALSE){
				//Add the cell array for each line as a new array value
				$arrResult[] = $data;
			}
			//Close the opened file
    		fclose($handle);
		}
		
		//Return the results execpt for the header line
		array_shift ( $arrResult);
		return $arrResult;
	}
	
	function getJSONResults(){
		$results = getQuotesOfTheDay();
		return json_encode($results);
	}
	
	echo getJSONResults();
?>