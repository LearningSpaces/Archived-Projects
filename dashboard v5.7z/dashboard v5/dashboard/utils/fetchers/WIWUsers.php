<?php
	require("../../vendor/autoload.php");
	
	date_default_timezone_set("America/Chicago");
	
	// Pull the json config file and assign the values to variables
	$config = json_decode(file_get_contents("../../config.json"));
	$username = $config->UserName;
	$password = $config->Password;
	$apiKey = $config->APIKey;
	
	// API info and token generation
	$response = Wheniwork::login($apiKey, $username, $password);
	$wiw = new Wheniwork($response->login->token);
	
	function getUsersJSON(){
		//Make global variables accessible
		global $wiw;
		
		$userList = $wiw->get('users',array('show_deleted'=>false))->users;
		
		$users = array();
		
		foreach ($userList as $user){
			$userInfo = array(
				'userID' => $user->id,
				'firstName' => $user->first_name,
				'lastName' => $user->last_name,
				'phoneNumber' => $user->phone_number,
				'punchedIn' => false,
				'locationID' => null
			);
			$users[] = $userInfo;
		}
		
		return json_encode($users);
	}
	
	echo getUsersJSON();
?>