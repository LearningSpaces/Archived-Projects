<?php
	require("../../vendor/autoload.php");
	
	date_default_timezone_set("America/Chicago");
	
	// Pull the json config file and assign the values to variables
	$config = json_decode(file_get_contents("../../config.json"));
	$username = $config->UserName;
	$password = $config->Password;
	$apiKey = $config->APIKey;
	
	// API info and token generation
	$response = Wheniwork::login($apiKey, $username, $password);
	$wiw = new Wheniwork($response->login->token);
	
	function getUsersJSON(){
		//Make global variables accessible
		global $wiw;
		
		//Get the current time
		$time = date("Y-m-d H:i:s",time());
		$timeNext = date("Y-m-d H:i:s",time()+30*60);
		
		//Get the shifts for the current time
		$shifts = $wiw->get('shifts/',array('start' => $time,'end' => $timeNext,'include_open' => false,'unpublished'=>false,'deleted'=>false))->shifts;
		
		$shiftList = array();
		
		foreach($shifts as $shift){
			
			$shiftList[] = array(
				'userID' => $shift->user_id,
				'locationID' => $shift->location_id
			);
		}
		
		return json_encode($shiftList);
	}
	
	echo getUsersJSON();
?>