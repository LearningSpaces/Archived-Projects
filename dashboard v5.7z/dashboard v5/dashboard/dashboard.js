/*dashboard.js
*
* Description:
* This file generates the content for the dashboard.html file. This includes the tech check table, cart status table, and when i work table.
* 
* Authors:
* Jacob Bass
* Austen Rozanski
* Connor McNeely
* Russell Kenney
*
* Date Last Updated: 02/24/2017
*/


//Refresh rate for each portion of the dashboard
var WIWSHIFT_REFRESH_INTERVAL = 1000*60;
var WIWPUNCH_REFRESH_INTERVAL = 1000*15;
var CARTSTATUS_REFRESH_INTERVAL = 1000*20;
var TECHCHECK_REFRESH_INTERVAL = 1000*5;
var DATETIME_REFRESH_INTERVAL = 1000*1;
var WEPA_REFRESH_INTERVAL = 1000*30;
var PRINTCHARGES_REFRESH_INTERVAL = 1000*30;
var TYSK_REFRESH_INTERVAL = 1000*3600; // one hour


//Colors used in the document
var ELEMENT_COLORS = {yellow:"#F7DC6F", red:"#EC7063", green:"#58D68D", gray:"#D5DBDB", darkGray:"#2a2e30"};

//Store all the timers used to refresh the table in this array
var timers = {};

//Variable used to store the number of tech check charts currently displaying.
//Once this number is assigned a value not equal to 0, the page will refresh if the number is changed again.
var numOfTCCharts = 0;

var wiwUsers = [];

function fetchWIWUsers(){
	console.log("Fetching WIW Users");
	getAsyncInfo('./utils/fetchers/WIWUsers.php','',writeWIWUsers);
	
}

function writeWIWUsers(results){
	wiwUsers = results;
	for(var i = 0; i < wiwUsers.length; i++){
		wiwUsers[i].working = false;
		if(wiwUsers[i].firstName == 'Ntuthuko (Tooks)'){
			wiwUsers[i].firstName = 'Tooks';
		}else if(wiwUsers[i].firstName == "David" && wiwUsers[i].lastName == 'Van Dorn'){
			wiwUsers[i].firstName = 'DVD';
			wiwUsers[i].lastName = '';
		}else if(wiwUsers[i].firstName == "Jasmine" && wiwUsers[i].lastName == 'Pearce'){
			wiwUsers[i].firstName = '2nd Lead OA, Jassy';
		}
	}
	timers.cart_status = setTimeout(function(){fetchShifts();},1000*10);
	timers.cart_status = setTimeout(function(){fetchPunchStatus();},1000*20);
}

function fetchShifts(){
	console.log("Fetching WIW Shifts");
	getAsyncInfo('./utils/fetchers/WIWShifts.php','',updateShifts);
	
}

function updateShifts(results){
	timers.wiwshifts = setTimeout(function(){getAsyncInfo('./utils/fetchers/WIWShifts.php','',updateShifts)},WIWSHIFT_REFRESH_INTERVAL);
	for(var index = 0; index < wiwUsers.length; index++){
		wiwUsers[index].working = false;
		for(var j = 0; j < results.length; j++){
			if(wiwUsers[index].userID == results[j].userID){
				wiwUsers[index].working = true;
				wiwUsers[index].locationID = results[j].locationID;
				break;
			}
		}
	}
}

function fetchPunchStatus(){
	console.log("Fetching WIW Punch Status");
	//for(var user in wiwUsers){
	for(var index = 0; index < wiwUsers.length-1; index++){
		getAsyncInfo('./utils/fetchers/WIWPunchStatus.php',wiwUsers[index].userID,updatePunchStatus);
	}
	getAsyncInfo('./utils/fetchers/WIWPunchStatus.php',wiwUsers[wiwUsers.length-1].userID,updateWIWTables);
}

function updatePunchStatus(results){
	for(var index = 0; index < wiwUsers.length; index++){
		if(wiwUsers[index].userID == results.userID){
			if(results.punchedIn){
				wiwUsers[index].punchedIn = true;
			}else{
				wiwUsers[index].punchedIn = false;
			}
			break;
		}
	}
}

function updateWIWTables(results){
	timers.wiwpunch = setTimeout(function(){fetchPunchStatus()},WIWPUNCH_REFRESH_INTERVAL);
	updatePunchStatus(results);
	
	var upcoming = '<caption class="workerTableELHeader">Upcoming</caption><tbody>';
	var el = '<caption class="workerTableELHeader">EL</caption><tbody>';
	var coa = '<caption class="workerTableCOAHeader">COA</caption><tbody>';
	var couch = '<caption class="workerTableCouchHeader">Couch</caption><tbody>';
	var hclc = '<caption class="workerTableHCLCHeader">HCLC</caption><tbody>';
	var sarkeys = '<caption class="workerTableSarkeysHeader">Sarkeys</caption><tbody>';
	console.log("Updating Tables");
	for(var index = 0; index < wiwUsers.length; index++){
		
		var phoneNumber = wiwUsers[index].phoneNumber;
		phoneNumber = "(" + phoneNumber.substr(2,3) + ") " + phoneNumber.substr(5,3) + "-" + phoneNumber.substr(8,4);
		
		var location = wiwUsers[index].locationID;
		if(location == 131576){
			var info = '<tr class="workerTableCOA"><td>'+ wiwUsers[index].firstName +' '+ wiwUsers[index].lastName +'</td><td align="right">'+phoneNumber+'</td></tr>';
			if(wiwUsers[index].punchedIn){
				coa += info;
			}else if(wiwUsers[index].working){
				upcoming += info;
			}
		}else if(location == 703771){
			var info = '<tr class="workerTableCouch"><td>'+ wiwUsers[index].firstName +' '+ wiwUsers[index].lastName +'</td><td align="right">'+phoneNumber+'</td></tr>';
			if(wiwUsers[index].punchedIn){
				couch += info;
			}else if(wiwUsers[index].working){
				upcoming += info;
			}
		}else if(location == 243480){
			var info = '<tr class="workerTableHCLC"><td>'+ wiwUsers[index].firstName +' '+ wiwUsers[index].lastName +'</td><td align="right">'+phoneNumber+'</td></tr>';
			if(wiwUsers[index].punchedIn){
				hclc += info;
			}else if(wiwUsers[index].working){
				upcoming += info;
			}
		}else if(location == 131584){
			var info = '<tr class="workerTableSarkeys"><td>'+ wiwUsers[index].firstName +' '+ wiwUsers[index].lastName +'</td><td align="right">'+phoneNumber+'</td></tr>';
			if(wiwUsers[index].punchedIn){
				sarkeys += info;
			}else if(wiwUsers[index].working){
				upcoming += info;
			}
		}else{
			var info = '<tr class="workerTableEL"><td>'+ wiwUsers[index].firstName +' '+ wiwUsers[index].lastName +'</td><td align="right">'+phoneNumber+'</td></tr>';
			if(wiwUsers[index].punchedIn){
				el += info;
			}else if(wiwUsers[index].working){
				upcoming += info;
			}
		}
	}
	document.getElementById('elWorkers').innerHTML = el +'</tbody>';
	document.getElementById('coaWorkers').innerHTML = coa +'</tbody>';
	document.getElementById('couchWorkers').innerHTML = couch +'</tbody>';
	document.getElementById('hclcWorkers').innerHTML = hclc +'</tbody>';
	document.getElementById('sarkeysWorkers').innerHTML = sarkeys +'</tbody>';
	document.getElementById('nextWorkers').innerHTML = upcoming +'</tbody>';
}

function updateTechChecks(results){
	
	//Set timer for when to update information for the tech check tables/charts
	timers.techchecks = setTimeout(function(){getAsyncTechChecks(updateTechChecks);},TECHCHECK_REFRESH_INTERVAL);
	
	console.log("Updating Tech Checks");
	try {
		// Since results is not an array, find its length
		var check = 0;
		var resultsLength = 0;
		while (typeof results["sector" + check] != 'undefined')
		{
			resultsLength++;
			check++;
		}
		
		//Refresh page if the number of sectors changes
		if (numOfTCCharts != 0 && numOfTCCharts != resultsLength) {
			location.reload(true);
		} else {
			numOfTCCharts = resultsLength;
		}
		
		// Static variable: first
		// Used to keep the charts from animating from 0 for every update
		if ( typeof updateTechChecks.first == 'undefined' ) {
			updateTechChecks.first = true;
			updateTechChecks.sectorCharts = [];
			
			//Nodes used to store portions of the tech check table
			var node1 = document.getElementById('techCheckTable');
			var node2 = document.getElementById('sectorNames');
			var node3 = document.getElementById('tableHeader');
			
			//Strings used for direct output to the html file
			var tableWidthsString = '';
			var canvasString = '';
			var nameString = '';
			var tableHeaderString = '<th colspan="'+(resultsLength)+'"><img src="./res/images/header_icons/Tech-Check-Icons.gif" align="left" style="padding-left:50px"><p align="center" style="padding-top:8px;padding-right:100px">Tech Checks</p></th>';
			
			// Create strings to be written to the html document to display the charts
			var columnWidth = 100/resultsLength < 33 ? 100/resultsLength : 33;
			for (i = 0; i < resultsLength; ++i)
			{
				canvasString += '<td><canvas id="sector' + (i) + 'Canvas"></canvas></td>';
				nameString += '<th width="'+ columnWidth +'%">' + results["sector" + i].sectorName + '</th>';
			}
			//Make sure table is at least three columns wide ()
			if (resultsLength < 3)  {
				for (i = 0; i < 3 - resultsLength; i++) {
					var headerString = "";
					if (i == 0) {
						headerString += 'Tech Checks';
					}
					tableHeaderString += '<th width="'+ columnWidth +'%">' + headerString + '</th>';
				}
			}
			
			//Assign the strings used in the loop above to their cooresponding nodes
			node1.innerHTML = canvasString;
			node2.innerHTML = nameString;
			node3.innerHTML = tableHeaderString;
		}
		
		//Store data for each of the graphs in these two arrays
		var sectorCtx = [];
		
		//Stores data cooresponding to each graph (color, values, and labels)
		var sectorData = [];

		
		// Update the data for each sector chart
		for (var i = 0; i < resultsLength; ++i)
		{
			//Reference used to get the charts by the html file
			sectorCtx[i] = document.getElementById("sector" + (i) + "Canvas").getContext("2d");
			
			//Data used with the circle charts
			sectorData[i] = [
				{
					// Completed
					value: (results["sector" + i].total == 0) ? 1 : results["sector" + i].completed,
					color: ELEMENT_COLORS.green,
					highlight: ELEMENT_COLORS.green,
					label: "Completed"
				},
				
				{
					// Work Required
					value: (results["sector" + i].total == 0) ? 0 : results["sector" + i].workRequired,
					color: ELEMENT_COLORS.red,
					highlight: ELEMENT_COLORS.red,
					label: "Work Required"
				},
				
				{
					// Could not get in
					value: (results["sector" + i].total == 0) ? 0 : results["sector" + i].couldNotGetIn,
					color: ELEMENT_COLORS.yellow,
					highlight: ELEMENT_COLORS.yellow,
					label: "Could not get in"
				},
				
				{
					// Remaining
					value: (results["sector" + i].total == 0) ? 0 : results["sector" + i].remaining,
					color: ELEMENT_COLORS.darkGray,
					highlight: ELEMENT_COLORS.darkGray,
					label: "Remaining"
				}
			]
		}

		var percentNode = document.getElementById('techCheckPercentages');
		var percentString = '';
		var labsChartNode = document.getElementById('labsChart');
		var labsChartString = '';
		var maxLabs = 0;
		
		//If the charts have not been created yet
		if(updateTechChecks.first){
			// Makes new charts with TechCheck data
			
			
			// Create new charts
			for (var i = 0; i < sectorCtx.length; ++i)
			{
				updateTechChecks.sectorCharts[i] = new Chart(sectorCtx[i]).Doughnut(sectorData[i], {segmentStrokeColor: "e39d2d", percentageInnerCutout : 70, animationEasing : "easeInOutCubic"});
				
				//Get the maximum number of labs out of all the sectors
				if (results["sector" + i].results.length > maxLabs) {
					maxLabs = results["sector" + i].results.length;
				}
				
				//Percent Complete String
				//Check if the number of labs is 0
				if (results["sector" + i].total == 0) {
					//Output 100% if the number of labs is 0
					percentString += '<td><font color="#000000">100%</font></td>';
				} else {
					//Output (completed/total)% if the number of labs is not 0
					console.log(results["sector"+i].completed);
					percentString += '<td><font color="#000000">' + Math.round(100 * (results["sector" + i].completed / results["sector" + i].total)) + '%</font></td>';
				}
				
			}
			
			updateTechChecks.first = false;
		}
		
		//Charts/tables have already been created, simply update the data.
		else {
			
			// Update each existing charts and table
			for (var i = 0; i < sectorCtx.length; ++i)
			{
				
				//Get the maximum number of labs out of all the sectors
				if (results["sector" + i].results.length > maxLabs) {
					maxLabs = results["sector" + i].results.length;
				}
				
				updateTechChecks.sectorCharts[i].segments[0].value = sectorData[i][0].value;
				updateTechChecks.sectorCharts[i].segments[1].value = sectorData[i][1].value;
				updateTechChecks.sectorCharts[i].segments[2].value = sectorData[i][2].value;
				updateTechChecks.sectorCharts[i].segments[3].value = (results["sector"+i].total - (sectorData[i][0].value + sectorData[i][1].value + sectorData[i][2].value));
				updateTechChecks.sectorCharts[i].update();
				
				console.log(sectorData[i][0].value + ", " + sectorData[i][1].value + ", " + sectorData[i][2].value + ", " + sectorData[i][3].value)
				
				//Percent Complete String
				//Check if the number of labs is 0
				if (results["sector" + i].total == 0) {
					//Output 100% if the number of labs is 0
					percentString += '<td><font color="#000000">100%</font></td>';
				} else {
					//Output (completed/total)% if the number of labs is not 0
					console.log(results["sector"+i].completed)
					percentString += '<td><font color="#000000">' + Math.round(100 * (results["sector" + i].completed / results["sector" + i].total)) + '%</font></td>';
				}
			}
		}
		
		//Create html string to output the labs table with the correct colors
		for (var rowIndex = 0; rowIndex < maxLabs; rowIndex++) {
			labsChartString += '<tr>';
			for (var columnIndex = 0; columnIndex < resultsLength; columnIndex++) {
				if (rowIndex < results["sector" + columnIndex].results.length) {
					if (results["sector" + columnIndex].results[rowIndex][1] == "1") {
						//Get lab name and set background color to green
						labsChartString += '<td bgcolor=' + ELEMENT_COLORS.green + '><font color="#000000">' + results["sector" + columnIndex].results[rowIndex][0] + '</td>';
					} else if (results["sector" + columnIndex].results[rowIndex][1] == "2") {
						//Get lab name and set background color to red
						labsChartString += '<td bgcolor=' + ELEMENT_COLORS.red + '><font color="#000000">' + results["sector" + columnIndex].results[rowIndex][0] + '</td>';
					} else if (results["sector" + columnIndex].results[rowIndex][1] == "3") {
						//Get lab name and set background color to yellow
						labsChartString += '<td bgcolor=' + ELEMENT_COLORS.yellow + '><font color="#000000">' + results["sector" + columnIndex].results[rowIndex][0] + '</td>';
					} else {
						//Get lab name and set background color to gray
						labsChartString += '<td bgcolor=' + ELEMENT_COLORS.gray + '><font color="#000000">' + results["sector" + columnIndex].results[rowIndex][0] + '</td>';
					}
				} else {
					//Output an empty cell if there is no lab in this row for the sector
					labsChartString += '<td></td>';
				}
			}
			labsChartString += '</tr>';
		}
		
		//Add key to labs chart
		labsChartString += '<tr><td colspan=' + resultsLength + '>&emsp;</td></tr>';
		labsChartString += '<tr><td colspan=3><font color="#000000">Key</td></tr>';
		labsChartString += '<tr><td bgcolor=' + ELEMENT_COLORS.green + '><font color="#000000">Finished</td><td bgcolor=' + ELEMENT_COLORS.yellow + '><font color="#000000">Could not get in</td><td  bgcolor=' + ELEMENT_COLORS.red + '><font color="#000000">Work required</td></tr>'
		
		//Assign the nodes with the value of the html strings created above
		percentNode.innerHTML = percentString;
		labsChartNode.innerHTML = labsChartString;
		
	} catch(e) {
		console.log(e);
	}
}

// Callback to update the Cart Status table
function updateCartStatus(results){
	
	//Set the cart_status timer
	timers.cart_status = setTimeout(function(){getAsyncCartsStatus(updateCartStatus);},CARTSTATUS_REFRESH_INTERVAL);
	
	//console.log("Updating Cart Status");
	
	// Get the #cart_status div object
	//var table = document.getElementById("cartStatusTable");
	var cartStatusNode = document.getElementById('cartStatusTable');
	var cartStatusString = '';
	
	// Output each of the rows for the cart table into the rows variable
	
	for(var i=0; i < results.carts.length; i++){
		
		var phoneNumber = results.carts[i].number;
		if (phoneNumber.length == 10) 
		{
			phoneNumber = "(" + phoneNumber.slice(0, 3) + ") " + phoneNumber.slice(3, 6) + "-" + phoneNumber.slice(6);
		}
		//cartStatusString += '<tr class="caseRow' + (i%2) + '"><td>'+results.carts[i].cart+'</td><td>a</td><td>a</td><td>a</td></tr>';
		
		cartStatusString += '<tr class="caseRow' + (i%2) + '"><td>'+results.carts[i].cart+'</td><td>'+results.carts[i].person+'</td><td>'+phoneNumber+
		'</td><td>'+getStatusIcon(results.carts[i].status_code)+'</td></tr>\n';
		
	}
	
	//cartStatusString += '<tr class="caseRow0"<td>a</td><td>a</td><td>a</td><td>a</td></tr>';
	
	//Assign the rows to the table
	cartStatusNode.innerHTML = cartStatusString;
}

// Returns an html img tag containing the paths to
// the red,yellow,and green icons given a status code.
// Used with the cart status table
function getStatusIcon(status_code){
	switch(status_code){
		case("0"):
			return "<img src='res/images/priority_icons/2_high_yellow.gif'>";
		case("1"):
			return "<img src='res/images/priority_icons/3_low_green.gif'>";
		case("2"):
			return "<img src='res/images/priority_icons/1_crit_red.gif'>";
		default:
			return "";
	}
}

// Pulls the current date/time and applies it to the #date_time div
function updateDateTime(){
	
	//Set the dateTime refresh timer
	timers.datetime = setTimeout(updateDateTime, DATETIME_REFRESH_INTERVAL);
	
	//console.log("Updating Time");
	
	try {
		// Get the #date_time div object
		var elem = document.getElementById("date_time");
		// Get current date/time
		var d = new Date();
		// Apply the formatted date to the #date_time div
		elem.innerHTML = getMonthString(d.getMonth())+" "+(d.getDate()<10?"0":"")+d.getDate()+", "+d.getFullYear()+" - "+(d.getHours()%12==0?12:d.getHours()%12)+":"+(d.getMinutes()<10?"0":"")+d.getMinutes()+" "+(d.getHours < 12 ? "AM" : "PM");
		
		// Translates the number returned from JavaScript's 
		function getMonthString(month){
			switch(month){
				case(0):
					return "January";
				case(1):
					return "February";
				case(2):
					return "March";
				case(3):
					return "April";
				case(4):
					return "May";
				case(5):
					return "June";
				case(6):
					return "July";
				case(7):
					return "August";
				case(8):
					return "September";
				case(9):
					return "October";
				case(10):
					return "November";
				case(11):
					return "December";
			}
		}
	} catch(e) {
		console.log(e);
	}
}

// Update the WEPA statuses of any Kiosks with warnings or error messages
function updateWEPAStatus(results){
	
	//Wait before updating again
	timers.wepa_status = setTimeout(function(){getAsyncWEPAStatus(updateWEPAStatus)}, WEPA_REFRESH_INTERVAL);

	
	//console.log("Updating WEPA Kiosks");
	
	//Get the table for WEPA
	var wepaNode = document.getElementById('wepaTable');
	//Create an empty String to write the rows of kiosks to
	var wepaHTMLString = '';
	
	var redCount = 0;
	var yellowCount = 0;
	
	//Cycle through each kiosk
	for (var i = 0; i < results.length; ++i) {
		//If the kiosk is green, ignore it.
		if (results[i].status.color != "GREEN")
		{
			
			//If the kiosk is red, add it to the beginning of the table
			if(results[i].status.color == "RED"){
				
				//Create a string containing the description and status alerts
				var kiosk = '<tr class="alert' + results[i].status.color + (redCount++ % 2) + '"><td>' + results[i].description + 
					'</td><td>' + results[i].status.alerts + '</td><td>'+ results[i].status.printerText +'</td></tr>';
				wepaHTMLString = kiosk + wepaHTMLString;
		  	}
			
			//If the kiosk is yellow, add it to the end of the table
			else{
				var kiosk = '<tr class="alert' + results[i].status.color + (yellowCount++ % 2) + '"><td>' + results[i].description + 
					'</td><td>' + results[i].status.alerts + '</td><td>'+ results[i].status.printerText +'</td></tr>';
				wepaHTMLString += kiosk;
			}
		}
	}
	//Write the table contents
	wepaNode.innerHTML = wepaHTMLString;
}

// Update the statuses of the BMI printers in the labs
/*
function updatePrinterStatus(results) {
	
	// Set the BMI refresh timer
	timers.bmi = setTimeout(function(){getAsyncPrinterStatus(updatePrinterStatus)}, PRINTCHARGES_REFRESH_INTERVAL);
	
	console.log("Updating lab printers.");
	
	// Get the id node for the printer table body
	var printerNode = document.getElementById('bmiPrinters');
	//Create an empty String to write the printers' data to
	var printerHTMLString = '';
	
	// Counts how many printers have errors of each color ('WARN' or 'ERROR')
	var redCount = 0;
	var yellowCount = 0;
	
	//Cycle through each kiosk
	for (var i = 0; i < results.length; ++i) {
		console.log("PRINT NAME: " + results[i].name);
		//If the kiosk is green ('OK'), ignore it.
		if (results[i].color != "GREEN")
		{	
			//Get the correct status message based on the printer text
			var statusMsg = results[i].printerText;
			
			//If the printer is red ('ERROR'), add it to the beginning of the table
			if(results[i].color == "RED"){
				
				// Set the color to be used for this item in the table as RED
				var color = "RED";
				
				//Create a string containing the description and status alerts
				var printer = '<tr class="printer' + color + (redCount++ % 2) + '"><td>' + results[i].name + 
					'</td><td>' + statusMsg + '</td></tr>';
				printerHTMLString = printer + printerHTMLString;
		  	}
			
			//If the printer is yellow ('WARN'), add it to the end of the table
			else{
				
				// Set the color to be used for this item in the table as YELLOW
				var color = "YELLOW";
				
				//Create a string containing the description and status alerts
				var printer = '<tr class="printer' + color + (yellowCount++ % 2) + '"><td>' + results[i].name + 
					'</td><td>' + statusMsg + '</td></tr>';
				printerHTMLString += printer;
			}
		}
	}
	//Write the table contents
	printerNode.innerHTML = printerHTMLString;
} */

//Update quote of the day
function updateThingsYouShouldKnow(results) {
	// Set the BMI refresh timer
	timers.qotd = setTimeout(function(){getAsyncTYSKStatus(updateThingsYouShouldKnow)}, TYSK_REFRESH_INTERVAL);
	
	var quoteIndex = Math.floor(Math.random() * results.length);
	var TYSKNode = document.getElementById('ThingsYouShouldKnow_out');
	TYSKNode.innerHTML = results[quoteIndex];
}

// Callback loaded when all of the elements on the page has loaded
/*window.onload = function (){
	//Updates Date/Time
	updateDateTime();
	// Updates the shift information
	getAsyncShifts('',updateShiftWorkers);
	//Update Tech Checks
	getAsyncTechChecks(updateTechChecks);
	//Update Cart Status
	getAsyncCartsStatus(updateCartStatus);
	//Update WEPA status
	getAsyncWEPAStatus(updateWEPAStatus);
	//Update Print charges status
	//getAsyncPrintChargesStatus(updatePrinterStatus);
	//Update TYSK
	getAsyncTYSKStatus(updateThingsYouShouldKnow);
	
	//Reload the page at 7 every morning
	
	var now = new Date();
	var timeToRefresh = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 7, 0, 0, 0) - now;
	if (timeToRefresh < 0) {
		timeToRefresh += 86400000; //86400000 ms = 24 hours
	}
	setTimeout(function(){location.reload(true);}, timeToRefresh);
};*/
window.onload = function (){
	updateDateTime();
	fetchWIWUsers();
	getAsyncTechChecks(updateTechChecks);
	getAsyncCartsStatus(updateCartStatus);
	getAsyncWEPAStatus(updateWEPAStatus);
	getAsyncTYSKStatus(updateThingsYouShouldKnow);
};